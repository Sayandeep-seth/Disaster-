from flask import Flask, render_template, request, jsonify
import requests
from twilio.rest import Client
import openai  # Import OpenAI

app = Flask(__name__)

# OpenAI API key (replace with your actual OpenAI API key)
openai.api_key = 'sk-AKxltHkrnoa9ah6I41WrCcPJELPL2XrQGcFA674FpTT3BlbkFJCrH6LyO0Hmg4OA_MtIOAFP3xSNR2MGMul8odxvxFQA'

# Twilio account credentials (replace with your actual credentials)
account_sid = 'AC5427505a89c5b598404ee0038442d444'
auth_token = '806428864dabde868dcaf3a7ca31432b'
twilio_client = Client(account_sid, auth_token)

# Get Earthquake Data from USGS
def get_earthquake_data():
    url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson"
    response = requests.get(url)
    data = response.json()
    return data

# Get Storm Data from OpenWeatherMap (replace 'YOUR_API_KEY' with your actual OpenWeatherMap API key)
def get_storm_data(city):
    api_key = 'ac3f0483ad32facd9d9a4d61401a5190'
    url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Will raise an HTTPError for bad responses (4xx or 5xx)
        return response.json()
    except requests.exceptions.HTTPError as err:
        return {'error': f"Error: {err}"}
    except Exception as e:
        return {'error': str(e)}

# Simple earthquake prediction based on magnitude
def earthquake_prediction(magnitudes):
    # Predict earthquake danger if magnitude is above 5.0
    predictions = [-1 if mag > 5.0 else 1 for mag in magnitudes]
    return predictions

# Function to send SMS alerts using Twilio
def send_alert(message, user_number):
    message = twilio_client.messages.create(
        body=message,
        from_='+1234567890',  # Your Twilio number
        to=user_number
    )
    return message.sid

# Function to get disaster insights from OpenAI
def get_disaster_insights(event_type, details):
    prompt = f"Provide detailed information and precautions regarding {event_type}. {details}"
    
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=150
        )
        return response.choices[0].text.strip()
    except Exception as e:
        return f"Error generating insights: {str(e)}"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        city = request.form['city']
        phone_number = request.form['phone']

        # Step 1: Get Earthquake Data
        earthquake_data = get_earthquake_data()
        magnitudes = [quake['properties']['mag'] for quake in earthquake_data['features']]

        # Step 2: Predict potential earthquakes
        predicted_disasters = earthquake_prediction(magnitudes)
        earthquake_alerts = []
        for idx, pred in enumerate(predicted_disasters):
            if pred == -1:
                message = f"Potential earthquake detected with magnitude: {magnitudes[idx]}"
                earthquake_alerts.append(message)
                send_alert(message, phone_number)

        # Step 3: Get Storm Data
        storm_data = get_storm_data(city)
        if 'error' in storm_data:
            return jsonify({'status': 'Error', 'message': storm_data['error']}), 400
        
        storm_alert = None
        if storm_data['weather'][0]['main'] in ['Thunderstorm', 'Tornado', 'Extreme']:
            storm_alert = f"Severe storm detected: {storm_data['weather'][0]['description']}"
            send_alert(storm_alert, phone_number)

        # Step 4: Generate disaster insights with OpenAI
        earthquake_details = f"Detected earthquake magnitudes: {', '.join(map(str, magnitudes))}"
        earthquake_insights = get_disaster_insights("earthquake", earthquake_details)
        
        if storm_alert:
            storm_insights = get_disaster_insights("storm", f"Weather conditions: {storm_data['weather'][0]['description']}")
        else:
            storm_insights = None

        # Combine all insights and alerts into the response
        response = {
            'status': 'Prediction and alerting process complete!',
            'earthquake_alerts': earthquake_alerts,
            'earthquake_insights': earthquake_insights,
            'storm_alert': storm_alert,
            'storm_insights': storm_insights
        }

        return jsonify(response)

    except Exception as e:
        return jsonify({'status': 'Error occurred', 'message': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
